 // all module imports
    var vcx = require('node-vcx-wrapper');
    var qr = require('qr-image');
    var fs = require('fs-extra');
    var ffi = require('ffi'); 
   //vcx imports
    const {
    Schema,
    CredentialDef,
    Connection,
    IssuerCredential,
    Proof,
    StateType,
    Error,
    rustAPI
    } = vcx;
    
    const config = "/vagrant/config/vcx-config.json";   
    // this function initializes libsovtoken and runs once when the script is run
    async function run(){
        const myffi = ffi.Library('/usr/lib/libsovtoken.so', {sovtoken_init: ['void', []]});
        await myffi.sovtoken_init();
    }
    run();

    async function testVCX(){
    try{
        await vcx.initVcx(config);
        return ("VCX has been successfully initiated");// return value will be displayed by make-runnable
    }catch(err){
        console.log("VCX has not been successfully initiated, see error below...");
        return(err);// return value will be displayed by make-runnable
         
   }
    }
    module.exports={
        testVCX
    }
    // make script runnable in CLI
        require('make-runnable/custom')({printOutputFrame: false})
